masculino(joao).
conjuge(joao,laura).
feminino(Y):-conjuge(X,Y),masculino(X).