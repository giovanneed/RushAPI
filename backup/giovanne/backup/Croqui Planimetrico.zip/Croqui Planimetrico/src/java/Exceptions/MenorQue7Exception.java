/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 *
 * @author Filipe LomelinoCardoso.
 */
public class MenorQue7Exception extends Exception {

    public MenorQue7Exception(String mensagem) {
        super(mensagem);
    }
}
